#!/bin/sh

mkdir -p $4/$2/lib

exit 0
