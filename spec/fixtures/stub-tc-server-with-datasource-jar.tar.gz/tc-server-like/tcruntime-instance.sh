#!/bin/sh

mkdir -p $4/$2/lib

SRC_DIR=$( cd "$( dirname "$0" )" && pwd )
cp $SRC_DIR/*.jar $4/$2/lib/.

exit 0
